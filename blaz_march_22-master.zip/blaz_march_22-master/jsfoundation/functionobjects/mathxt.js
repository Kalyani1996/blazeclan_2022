// IN this file we will implement the prototype

Mathematics.prototype.mult = function(a,b){
    return a * b;
}
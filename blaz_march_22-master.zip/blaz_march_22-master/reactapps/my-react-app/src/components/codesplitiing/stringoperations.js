export class StringOperations {
    getLength(str){
        return str.length;
    }
}

const NotFoundComponent=()=>{
    return (
        <div className="container">
            <strong>
                The resource you are looking for is missing
            </strong>
        </div>
    );
};

export default NotFoundComponent;
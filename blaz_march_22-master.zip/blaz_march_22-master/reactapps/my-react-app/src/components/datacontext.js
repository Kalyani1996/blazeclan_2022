// creating the context that will be used by multiple components
import React, {createContext} from 'react'
// define context with initial value
export const DataContext = createContext(null);